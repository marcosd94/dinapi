<?php
class ActividadObject extends DataObject {
  private static $db = array (
    'Nombre'=> 'Varchar',
    'Icono' => 'Varchar',
    'Fecha' => 'Date',
    'Lugar' => 'Varchar',
    'Hora'  => 'Time'
  );
  private static $can_be_root = false;

  private static $singular_name = "Actividad";

  private static $plural_name = "Actividades";

  private static $has_one = array (
    'Calendario' => 'CalendarioObject',
    'Imagen' => 'File'
  );
  private static $summary_fields = array (
      'Nombre' => 'Nombre',
      'Fecha.Nice' => 'Fecha',
      'Hora.Nice' => 'Hora',
      'Lugar' => 'Dirección / Lugar'
  );
  public function getCMSFields() {

    $options = array(
      "graduation-cap" => "Capacitación",
      "note-beamed" => "Concierto / Recital",
      "ticket" => "Evento / Cine",
      "tools" => "Taller",
      "trophy" => "Torneo"
      );


    $fields = parent::getCMSFields();
    $fields = FieldList::create(
        TextField::create('Nombre', 'Actividad'),
        TextField::create('Lugar', 'Dirección'),
        DateField::create('Fecha', 'Fecha') ->setConfig('showcalendar', true),
        TimePickerField::create('Hora', 'Hora'),
        DropdownField::create('Icono', 'Icono', $options)
          ->setEmptyString('(Elegir un icono)'),
        $uploader = UploadField::create('Imagen'),
        DropdownField::create('Calendario', 'Calendario', CalendarioObject::get()->map('ID', 'Nombre'))
                ->setEmptyString('(Elegir un calendario)')
    );

    $uploader->setFolderName('fotos-calendario');
    $uploader->getValidator()->setAllowedExtensions(array('png','gif','jpeg','jpg'));

    return $fields;
  }
}
