<?php

class ActividadesAdmin extends ModelAdmin {

    private static $menu_title = 'Actividades';

    private static $url_segment = 'actividades';

    private static $managed_models = array (
        'ActividadObject','CalendarioObject'
    );

    private static $menu_icon = 'mysite/iconos/actividades.png';
}